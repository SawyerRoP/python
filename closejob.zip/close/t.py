#!/usr/bin/env python
import requests;
from bs4 import BeautifulSoup
import re;

def login():
	url = 'http://helpdesk.lhs.co.th';
	page = requests.get('http://helpdesk.lhs.co.th');
	soup = BeautifulSoup(page.content, 'html.parser')
	__VIEWSTATE = soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value'];
	__VIEWSTATEGENERATOR = soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value'];
	__EVENTVALIDATION = soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value'];
	print(__VIEWSTATE)
	print(__VIEWSTATEGENERATOR)
	print(__EVENTVALIDATION)
