#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
urlget = 'http://119.160.218.5/hlpdsk/index.php';
url_login = 'http://119.160.218.5/hlpdsk_pcc/check_login.php';
data = {	      
		"username":"tech",
		"password":"lhs2541",
		"Submit":"Login"
	}	   
headers = { 
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'Accept-Encoding': 'gzip, deflate',
	'Accept-Language': 'en-US,en;q=0.9',
	'Cache-Contro': 'max-age=0',
	'Connection': 'keep-alive',
	'Content-Length': '364',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Host': 'helpdesk.lhs.co.th',
	'Origin': 'http://119.160.218.5/hlpdsk_pcc/',
	'Referer': 'http://119.160.218.5/hlpdsk_pcc/check_login.php',
	'Cookie': '',
	'Upgrade-Insecure-Requests': '1',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
}
def cookie():
    load = requests.session();
    page = load.get(urlget);
    cookie = load.cookies.get_dict();
    return cookie['PHPSESSID'];
    
def cookie_login(cookies):
    headers_oost_login = { 
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'Accept-Encoding': 'gzip, deflate',
	'Accept-Language': 'en-US,en;q=0.9',
	'Cache-Contro': 'max-age=0',
	'Connection': 'keep-alive',
	'Content-Length': '364',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Host': 'helpdesk.lhs.co.th',
	'Origin': 'http://119.160.218.5/hlpdsk_pcc/',
	'Referer': 'http://119.160.218.5/hlpdsk_pcc/check_login.php',
	'Cookie':'PHPSESSID='+cookies,
	'Upgrade-Insecure-Requests': '1',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
    }
    load = requests.session();
    page = load.post(url_login,data = data,headers = headers_oost_login)
    cookie = load.cookies.get_dict();
    return cookies;    
   