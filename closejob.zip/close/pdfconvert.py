#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import time;
import codecs;
import regex;



def getCallCheck():
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div');
	count = len(Problem);
	call = '';
	for i in range(count):
		content = Problem[i].text;
		re = regex.compile(r'รหัสการแจ้ง : ([a-z|0-9][a-z|0-9][a-z|0-9][0-9][0-9][0-9][0-9|a-z][0-9|a-z][0-9|a-z][0-9|a-z])',regex.I);
		if re.findall(content):
			call = re.findall(content);
			call = call[0];
			return call;
			break;
	f.close();
	

def getDate():
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div');
	count = len(Problem);
	for i in range(count):
		if i >= 17:
			content = Problem[i].text;
			#print(content);
			re = regex.compile(r'วันที่ดำเนินการเสร็จ (.*)',regex.I);
			name = re.findall(content);
			if name:
				time = re.findall(content);
				time = time[0];
				date = time[10:-14];
				mount = time[13:-11];
				year = time[16:-6];
				hour = time[21:-3]
				minute = time[24:];
				#print(hour);
				return date,mount,year,hour,minute;	
				
				print(date);
				print(mount);
				print(year);
				print(hour);
				print(minute);
				









	
	
def getProblem():
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div');
	count = len(Problem);
	name = '';
	for i in range(count):
		if i >= 17:
			content = Problem[i].text;
			#print(content);
			re = regex.compile(r'สาเหตุการเสีย:(.*)',regex.I);
			name = re.findall(content);
		if name:
			file = re.findall(content);
			name = file[0]
			#print('problem:',name);
			return name;
			#print(i);
	f.close();	
def getSolvproblem():
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div');
	count = len(Problem);
	solvproblem = '';
	contentSolv = [];
	stop = 'ผลการบริการ';
	solvproblem2 = '';
	for i in range(count):	
		if i >= 17:
			solv_data = Problem[i].text;
			solv = regex.compile(r'วิธีการแก้ไข:(.*)',regex.I);
			solvproblem = solv.findall(solv_data);
		if solvproblem:
			solv2 = solv.findall(solv_data);
			solv3 = solv2[0];
			#print(solv3);
			#print(i);
			contentSolv.append(solv3);
			i = i + 1;
			solvproblem2 = Problem[i].text;
			if solvproblem2:
				stop2 = Problem[i].text;
				if regex.search(stop2,stop):
					#print('solvproblem:',solvproblem2);
					#print(i);
					contentSolv.append('');
					#print('solvproblem:',contentSolv[0])
					#print('None line3');
					data = 'None line3';
					return contentSolv[0],data;
				else:
					contentSolv.append(stop2);
					con = contentSolv[0] + contentSolv[1];
					#print('solvproblem:',con);
					#print('[+]Have line3');
					data = 'Have line3';
					return con,data;	
	f.close();
	
def regexName(n):
	re = regex.compile(r'นาย(.*)|คุณ(.*)',regex.I)
	if re.findall(n):
		file = re.findall(n);
		name = file[0]
		return name[0]
	else:
		return n;			
					
def getName():
	check = 'ลงชื่อ';
	for i in range(count):
		if i >= 17:
			content_check = Problem[i].text;
			name = regex.compile(r'ลงชื่อ(\.(.*))',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(content_check);
				i = i + 1;
				Name = Problem[i].text;
				
				#print(type(Name));
				#print(Name[1:-1]);
				name = Name[1:-1]
				print(name);
				n = regexName(name)
				code_0103 = regex.compile(r'ตนุภพ (.*)',regex.I);
				if code_0103.findall(n):
					na = code_0103.findall(n)
					p = na[0]
					print(p);
					break;
				#return Name[1:-1];
				
#getName();
#print(a);		
#getName();		
#problem = getBodyClosecall();
#solv = getSolvproblem();

