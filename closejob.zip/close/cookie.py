#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup
import re;
import requests
import sys


url = 'http://helpdesk.lhs.co.th';
page = requests.get(url);
soup = BeautifulSoup(page.content, 'html.parser')
__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);


data = {	      
        "__LASTFOCUS":"",
		"__VIEWSTATE":__VIEWSTATE, 
		"__EVENTTARGET":"",
		"__EVENTARGUMENT":"",
        "__VIEWSTATEGENERATOR":__VIEWSTATEGENERATOR, 
        "__EVENTVALIDATION":__EVENTVALIDATION, 
        "tuser":"tech",
        "tpwd":"user",
        "btsignin":"Sign In"
        } 

EMAIL = ''
PASSWORD = ''

URL = 'http://helpdesk.lhs.co.th/indexuser.aspx'

def main():
    # Start a session so we can have persistant cookies
    session = requests.session(config={'verbose': sys.stderr})

  
    r = session.post(URL, data = data)

    # Try accessing a page that requires you to be logged in
    r = session.get('http://helpdesk.lhs.co.th/indexuser.aspx')
    print(r)

if __name__ == '__main__':
    main()