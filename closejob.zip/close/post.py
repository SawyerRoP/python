#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import get_time;
import re;
import time;
import pdfconvert;
import nameP;
import regex;

nameAlert = '';
"""
headers = { 
	'Host': 'helpdesk.lhs.co.th',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-US,en;q=0.5',
	'Accept-Encoding': 'gzip, deflate',
	'Referer': 'http://helpdesk.lhs.co.th/closecall.aspx',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Content-Length': '10083',
	'Connection': 'keep-alive',
	'Cookie': 'AspxAutoDetectCookieSupport=1;',
	'Upgrade-Insecure-Requests': '1'
	}
"""
def post(call):
	headers = {
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.9',
		'Cache-Contro': 'max-age=0',
		'Connection': 'keep-alive',
		'Content-Length': '364',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Host': 'helpdesk.lhs.co.th',
		'Origin': 'http://helpdesk.lhs.co.th',
		'Referer': 'http://helpdesk.lhs.co.th/',
		'Cookie': '?AspxAutoDetectCookieSupport=1;',
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
	}


	url = 'http://helpdesk.lhs.co.th/';
	url_login = 'http://helpdesk.lhs.co.th/login.aspx';
	urlclose_call = 'http://helpdesk.lhs.co.th/closecall.aspx'
	page = requests.get(url);
	soup = BeautifulSoup(page.content, 'html.parser')
	__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
	__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
	__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);

	data = {
		"__LASTFOCUS":"",
		"__VIEWSTATE":__VIEWSTATE,
		"__EVENTTARGET":"",
		"__EVENTARGUMENT":"",
		"__VIEWSTATEGENERATOR":__VIEWSTATEGENERATOR,
		"__EVENTVALIDATION":__EVENTVALIDATION,
		"tuser":"tech",
		"tpwd":"user",
		"btsignin":"Sign In"
	}

	load = requests.session();
	page = load.post(url_login,data = data,headers = headers);
	close = load.get(urlclose_call);
	cookie = load.cookies.get_dict();
	soup = BeautifulSoup(close.content, 'html.parser')
	__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
	__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
	__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);

	headersPost = {
		'Host': 'helpdesk.lhs.co.th',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'en-US,en;q=0.5',
		'Accept-Encoding': 'gzip, deflate',
		'Referer': 'http://helpdesk.lhs.co.th/closecall.aspx',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Content-Length': '10083',
		'Connection': 'keep-alive',
		'Cookie': 'AspxAutoDetectCookieSupport=1; ASP.NET_SessionId=' + cookie['ASP.NET_SessionId'],
		'Upgrade-Insecure-Requests': '1'
	}
		
		

	#print(close.text);
		
	if __VIEWSTATE:
		print('[+]VIEWSTATE OK')
		time.sleep(1);
	if __VIEWSTATEGENERATOR:
		print('[+]VIEWSTATEGENERATOR OK')
		time.sleep(1);
	if __EVENTVALIDATION:
		print('[+]EVENTVALIDATION OK');
		time.sleep(1);
	print('[+]coookie:',cookie['ASP.NET_SessionId']);
	d,m,y,h,mi = pdfconvert.getDate();
	d = get_time.regexHour(d);
	m = get_time.regexHour(m);
	h = get_time.regexHour(h);
	mi = get_time.regexHour(mi)
	problem = pdfconvert.getProblem();
	solvproblem,data  = pdfconvert.getSolvproblem();
	getName = nameP.getName();
	detail = 'สาเหตุการเสีย:' + problem + 'วิธีการแก้ไข:' + solvproblem;
	
	#CodeName = listTech.regexName(getName);
	#Name = listTech.getRegexName(CodeName);
		
	print('{}:{}:{}:{}:{} [+]problem:{}'.format(h,mi,d,m,y,problem));
	print('{}:{}:{}:{}:{}[+]solvproblem:{}'.format(h,mi,d,m,y,solvproblem));
	print('{}:{}:{}:{}:{}[+]solvproblem:{}'.format(h,mi,d,m,y,data));
	print('{}:{}:{}:{}:{}[+]TechincianCODE:{}'.format(h,mi,d,m,y,getName));
	#print(d,h,mi,m,y);

	
	dataPost = {
		'__EVENTTARGET':'',
		'__EVENTARGUMENT':'',
		'__LASTFOCUS':'',
		'__VIEWSTATE':__VIEWSTATE,
		'__VIEWSTATEGENERATOR':__VIEWSTATEGENERATOR,
		'__VIEWSTATEENCRYPTED':'',
		'__EVENTVALIDATION':__EVENTVALIDATION,
		'tcall': call,
		'tdetail':detail,
		'ddate':d,
		'dmonth':m,
		'dyear': y,
		'dhour': h,
		'tminute': mi, 
		'dtech': getName,
		'TextBox1':'0', 
		'rbt1': '1',
		'Button1': 'บันทึกข้อมูล'
		}
	post = load.post(urlclose_call,dataPost,headers = headersPost);
	#print(post.text);
	alert = regex.compile(r'alert(.*)',regex.I);
	if alert.findall(post.text):
		content_alert = alert.findall(post.text);
		nameAlert = content_alert[0];
		print('[+]Close:',nameAlert[10:-17]);
		time.sleep(1);
	




