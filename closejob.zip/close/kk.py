# coding=utf8
# the above tag defines encoding for this document and is for Python 2.x compatibility

import re

regex = r"(<input id=\"__VIEWSTATEGENERATOR\" name=\"__VIEWSTATEGENERATOR\" type=\"hidden\" value=\"(.*)\")"

test_str = ("<div class=\"container\">\n"
	"<form action=\"./?AspxAutoDetectCookieSupport=1\" id=\"form1\" method=\"post\">\n"
	"<input id=\"__VIEWSTATE\" name=\"__VIEWSTATE\" type=\"hidden\" value=\"/wEPDwUKLTMzNDE0ODA3MmRkrSP7ZPIQEFTnRbmZqVnth7DY6kstYFG94wXyuPIrwOg=\"/>\n"
	"<input id=\"__VIEWSTATEGENERATOR\" name=\"__VIEWSTATEGENERATOR\" type=\"hidden\" value=\"C2EE9ABB\"/>\n"
	"<input id=\"__EVENTVALIDATION\" name=\"__EVENTVALIDATION\" type=\"hidden\" value=\"/wEdAATjF06yKu/BgKjLnkct9EIzUZEkCyD9n9uOkxwOVGr6ABLSxc4J2jbgAisznbPhjYWNwAGeA9ffLfl+/izRuTGNFLaXkkIPew2OLztsmSFci7+BjMJwhIpGxK5MuMrLI9U=\"/>\n"
	"<div>\n"
	"<h2>LHS Helpdesk</h2>\n"
	"</div>\n"
	"<div id=\"textbox\">\n"
	"<input id=\"tuser\" name=\"tuser\" placeholder=\"Enter Username\" type=\"text\"/>\n"
	"<input id=\"tpwd\" name=\"tpwd\" placeholder=\"Enter Password\" type=\"password\"/>\n"
	"</div>\n"
	"<div>\n"
	"<input class=\"button\" id=\"btsignin\" name=\"btsignin\" type=\"submit\" value=\"Sign In\"/>\n"
	"</div>\n"
	"</form>\n"
	"</div>")

matches = re.finditer(regex, test_str, re.MULTILINE)

for matchNum, match in enumerate(matches):
    matchNum = matchNum + 1
    
    print ("Match {matchNum} was found at {start}-{end}: {match}".format(matchNum = matchNum, start = match.start(), end = match.end(), match = match.group()))
    
    for groupNum in range(0, len(match.groups())):
        groupNum = groupNum + 1
        
        print ("Group {groupNum} found at {start}-{end}: {group}".format(groupNum = groupNum, start = match.start(groupNum), end = match.end(groupNum), group = match.group(groupNum)))

# Note: for Python 2.7 compatibility, use ur"" to prefix the regex and u"" to prefix the test string and substitution.



def document_to_html(file_path):
    tmp = "/tmp"
    guid = str(uuid.uuid1())
    # convert the file, using a temporary file w/ a random name
    command = "abiword -t %(tmp)s/%(guid)s.html %(file_path)s; cat %(tmp)s/%(guid)s.html" % locals()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, cwd=os.path.join(settings.PROJECT_DIR, "website/templates"))
    error = p.stderr.readlines()
    if error:
        raise Exception("".join(error))
    html = p.stdout.readlines()
    return "".join(html)