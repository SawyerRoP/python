#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import pdfconvert;
import get_time;

d,m,y,h,mi = pdfconvert.getDate();


d = get_time.regexHour(d);
m = get_time.regexHour(m);
h = get_time.regexHour(h);
mi = get_time.regexHour(mi)

	
print(h,d,m,mi,y);
	