#!/usr/bin/env python
# -*- coding: utf-8 -*-
import time;
from time import gmtime,strftime
import regex;


localtime = time.asctime( time.localtime(time.time()) )	
def regexHour(n):
	re = regex.compile(r'0([1-9])',regex.I);
	hour = re.findall(n)
	if hour:
		h = re.findall(n);
		#print(hour);
		hour = h[0];
		return hour;
	else:
		return n;
		
def getTime():
	localtime = time.asctime( time.localtime(time.time()) )	
	day = localtime[9:-14];
	day = day.encode('utf-8');
	hour = localtime[11:-11];
	hour = regexHour(hour);
	hour = hour.encode('utf-8');
	minute = localtime[14:-8];
	minute = minute.encode('utf-8');
	mount = time.strftime("%m").encode('utf-8');
	year = time.strftime("%Y")
	year = 543 + int(year);
	year = str(year);
	year = year.encode('utf-8');
	return day,hour,minute,mount,year;

	
#d,h,mi,m,y = getTime();


"""	
year = time.strftime("%Y")
print(year);
year = 543 + int(year);
print(year);
"""
#print(day+"  "+mount+"  "+year+hour+": " +minute);
