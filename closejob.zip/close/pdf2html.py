#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import time;
import codecs;
import regex;


def getBodyClosecall():
	# These code snippets use an open-source library. http://unirest.io/python
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div',{'class':'t m0 x4 h8 y12 ff2 fs4 fc0 sc0 ls0 ws0'});
	solvProblem = [];
	Name = document.find_all('div',{'class':'t m0 x6 h7 y21 ff2 fs3 fc0 sc0 ls0 ws0'})
	p1 = document.find_all('div',{'class':'t m0 x4 h8 y13 ff2 fs4 fc0 sc0 ls0 ws0'})
	p2 = document.find_all('div',{'class':'t m0 x4 h8 y14 ff2 fs4 fc0 sc0 ls0 ws0'})
	p3 = document.find_all('div',{'class':'t m0 x4 h8 y15 ff2 fs4 fc0 sc0 ls0 ws0'})
	if p1:
		solvProblem.append(p1[0].text)
	if p2:
		solvProblem.append(p2[0].text)
		Name = document.find_all('div',{'class':'t m0 x6 h7 y22 ff2 fs3 fc0 sc0 ls0 ws0'})
		#print(Name);
	else:
		solvProblem.append('')
		

	#print(solvProblem);
			
	b = Name[0].text;
	c = Problem[0].text;
	name = b.encode('utf-8');
	problem = c.encode('utf-8');
	#solv = a.encode('utf-8');.
	return name,problem,solvProblem;
	"""
	with open('me.txt', 'a') as f:
		f.write(solv)
	with open('me.txt', 'a') as f:
		f.write(name[1:-1])
	with open('me.txt', 'a') as f:
		f.write(problem)
	"""
