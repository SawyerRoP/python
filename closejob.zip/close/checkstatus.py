#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import time;

def check(calls,cookie):

	headers = { 
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.9',
		'Cache-Contro': 'max-age=0',
		'Connection': 'keep-alive',
		'Content-Length': '364',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Host': 'helpdesk.lhs.co.th',
		'Origin': 'http://119.160.218.5/hlpdsk_pcc/',
		'Referer': 'http://119.160.218.5/hlpdsk_pcc/check_login.php',
		'Cookie': '',
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
	}
	
	url = 'http://helpdesk.lhs.co.th/';
	url_login = 'http://119.160.218.5/hlpdsk_pcc/check_login.php';
	data = {	      
		"username":"tech",
		"password":"lhs2541",
		"Submit":"Login"
	}
	i = 1;
	load = requests.session();
	page = load.post(url_login,data = data,headers = headers);
    #cookie = load.cookies.get_dict();
	
	#pag = load.get('http://119.160.218.5/hlpdsk_pcc/menu.php');
	#cookie = load.cookies;
	#print(pag.text);
	#print(cookie);
	
	#cookie = cookie['PHPSESSID'];
	headers_post = { 
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.9',
		'Cache-Contro': 'max-age=0',
		'Connection': 'keep-alive',
		'Content-Length': '364',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Host': 'helpdesk.lhs.co.th',
		'Origin': 'http://119.160.218.5/hlpdsk_pcc/',
		'Referer': 'http://119.160.218.5/hlpdsk_pcc/helpdesk/find_call.php',
		'Cookie': 'PHPSESSID='+cookie,
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
	}
	#print(page.status_code);
	callComplete = [];
	data_post = {
		'sn':calls,
		'Submit':'Find'
	}
	page = load.post('http://119.160.218.5/hlpdsk_pcc/helpdesk/find_call.php',data = data_post,headers = headers_post);
	callData = BeautifulSoup(page.text, 'lxml')
	callNumber = callData.find_all('a')
	if callNumber:
		if callNumber[0].text == 'Complete':
			#time.sleep(1);
			return callNumber[0].text;
		else:
			#print('{} {} {}'.format([i],call,'Call data Notfound'));		
			#time.sleep(1);
			return callNumber[0].text;
