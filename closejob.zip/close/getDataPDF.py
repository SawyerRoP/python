#!/usr/bin/env python
# -*- coding: utf-8 -*-
from PyPDF2 import PdfFileWriter, PdfFileReader

output = PdfFileWriter()
input1 = PdfFileReader(open("ThaiPDF.pdf", "rb"))



print(input1.numPages);

page = input1.getPage(0);
print(page.extractText);