#!/usr/bin/env python
import requests;
from bs4 import BeautifulSoup
import re;


data = {	      
        "username":"tech",
        "password":"lhs2541",
        "Submit":"Login"
        } 
  
page = requests.post('http://119.160.218.5/hlpdsk/check_login.php',data = data);
file = requests.get('http://119.160.218.5/hlpdsk/menu.php');

print(file.text);

	
	