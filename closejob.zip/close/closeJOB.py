#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os;
import requests;
from bs4 import BeautifulSoup;
import checkstatus;
import time;
import getPDF;
import post;
import pdfconvert;
import cookiePCC;


headers = { 
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.9',
		'Cache-Contro': 'max-age=0',
		'Connection': 'keep-alive',
		'Content-Length': '364',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Host': 'helpdesk.lhs.co.th',
		'Origin': 'http://helpdesk.lhs.co.th',
		'Referer': 'http://helpdesk.lhs.co.th/',
		'Cookie': '?AspxAutoDetectCookieSupport=1;',
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
		}
url = 'http://helpdesk.lhs.co.th/';
url_login = 'http://helpdesk.lhs.co.th/login.aspx';
page = requests.get(url);
soup = BeautifulSoup(page.content, 'html.parser')
__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);	


data = {	      
	"__LASTFOCUS":"",
	"__VIEWSTATE":__VIEWSTATE,
	"__EVENTTARGET":"",
	"__EVENTARGUMENT":"",
	"__VIEWSTATEGENERATOR":__VIEWSTATEGENERATOR,
	"__EVENTVALIDATION":__EVENTVALIDATION,
	"tuser":"tech",
	"tpwd":"user",
	"btsignin":"Sign In"
	}
load = requests.session();
page = load.post(url_login,data = data,headers = headers);
urlclose = 'http://helpdesk.lhs.co.th/callnoclose.aspx';
data = load.get(urlclose);
call = BeautifulSoup(data.text, 'lxml')
call_id = call.find_all('a');
cookieIndex = cookiePCC.cookie()
cookies = cookiePCC.cookie_login(cookieIndex)
print('Cookies:{}'.format(cookies));
callShow = [];
for calls in call_id:
	#print(calls.text);
	callShow.append(calls.text.strip());
	
count = 1;
for i in callShow:
	complete = checkstatus.check(i,cookies);
	print('{}callstatus:{} {}'.format([count],i,complete));
	if complete == 'Complete':
		#print('{} {} {}'.format([count],i,complete));
		count = count + 1;
		time.sleep(1);
		getPDF.loadPDF(i);
		callName = pdfconvert.getCallCheck();
	
		if callName != i:
			continue;
		else:
			post.post(i);
			#print('continue...');
			print('');
			print('');
			#a = input();
	else:
		count = count + 1;
		continue;
