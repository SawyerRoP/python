#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import get_time;
import re;
import time;
import pdfconvert;
import nameP;
import regex;

call = 'IT1811K8GA'
"""
headers = { 
	'Host': 'helpdesk.lhs.co.th',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-US,en;q=0.5',
	'Accept-Encoding': 'gzip, deflate',
	'Referer': 'http://helpdesk.lhs.co.th/closecall.aspx',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Content-Length': '10083',
	'Connection': 'keep-alive',
	'Cookie': 'AspxAutoDetectCookieSupport=1;',
	'Upgrade-Insecure-Requests': '1'
	}
"""
def post(call):
	headers = {
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.9',
		'Cache-Contro': 'max-age=0',
		'Connection': 'keep-alive',
		'Content-Length': '364',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Host': 'helpdesk.lhs.co.th',
		'Origin': 'http://helpdesk.lhs.co.th',
		'Referer': 'http://helpdesk.lhs.co.th/',
		'Cookie': '?AspxAutoDetectCookieSupport=1;',
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
	}


	url = 'http://helpdesk.lhs.co.th/';
	url_login = 'http://helpdesk.lhs.co.th/login.aspx';
	urlclose_call = 'http://helpdesk.lhs.co.th/closecall.aspx'
	page = requests.get(url);
	soup = BeautifulSoup(page.content, 'html.parser')
	__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
	__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
	__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);

	data = {	      
		"__LASTFOCUS":"",
		"__VIEWSTATE":__VIEWSTATE,
		"__EVENTTARGET":"",
		"__EVENTARGUMENT":"",
		"__VIEWSTATEGENERATOR":__VIEWSTATEGENERATOR,
		"__EVENTVALIDATION":__EVENTVALIDATION,
		"tuser":"tech",
		"tpwd":"user",
		"btsignin":"Sign In"
	}

	load = requests.session();
	page = load.post(url_login,data = data,headers = headers);
	close = load.get(urlclose_call);
	cookie = cookie = load.cookies.get_dict();
	soup = BeautifulSoup(close.content, 'html.parser')
	__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
	__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
	__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);

	headersPost = { 
		'Host': 'helpdesk.lhs.co.th',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'en-US,en;q=0.5',
		'Accept-Encoding': 'gzip, deflate',
		'Referer': 'http://helpdesk.lhs.co.th/closecall.aspx',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Content-Length': '10083',
		'Connection': 'keep-alive',
		'Cookie': 'AspxAutoDetectCookieSupport=1; ASP.NET_SessionId=' + cookie['ASP.NET_SessionId'],
		'Upgrade-Insecure-Requests': '1'
	}
	
	

	#print(close.text);
	
	if __VIEWSTATE: 
		print('[+]VIEWSTATE OK')
		time.sleep(1);
	if __VIEWSTATEGENERATOR:
		print('[+]VIEWSTATEGENERATOR OK')
		time.sleep(1);
	if __EVENTVALIDATION:
		print('[+]EVENTVALIDATION OK');
		time.sleep(1);
	print('[+]coookie:',cookie['ASP.NET_SessionId']);
	day,hour,minute,mount,year = get_time.getTime();
	d = day.decode('utf-8');
	h = hour.decode('utf-8');
	mi = minute.decode('utf-8');
	m = mount.decode('utf-8');
	y = year.decode('utf-8');
	problem = pdfconvert.getProblem();
	solvproblem,data  = pdfconvert.getSolvproblem();
	getName = nameP.getName();
	detail = problem + solvproblem;
	callName = pdfconvert.getCallCheck();
	#CodeName = listTech.regexName(getName);
	#Name = listTech.getRegexName(CodeName);
	if call == callName:
		print(callName);
	print('[+]problem:',problem);
	print('[+]solvproblem:',solvproblem);
	print('[+]',data);
	print('[+]codename:',getName);
	
	dataPost = {
		'__EVENTTARGET':'',
		'__EVENTARGUMENT':'',
		'__LASTFOCUS':'',
		'__VIEWSTATE':__VIEWSTATE,
		'__VIEWSTATEGENERATOR':__VIEWSTATEGENERATOR,
		'__VIEWSTATEENCRYPTED':'',
		'__EVENTVALIDATION':__EVENTVALIDATION,
		'tcall':call,
		'tdetail':detail,
		'ddate':d,
		'dmonth':m,
		'dyear': y,
		'dhour': h,
		'tminute': mi, 
		'dtech': getName,
		'TextBox1':'0', 
		'rbt1': '1',
		'Button1': 'บันทึกข้อมูล'
	}
	
	post = load.post(urlclose_call,dataPost,headers = headersPost);
	#print(post.text);
	alert = regex.compile(r'alert(.*)',regex.I);
	if alert.findall(post.text):
		content_alert = name.findall(post.text);
		name = content_name[0];
		print(name);

	

"""	
post2();
	
calls = [];
calls = login_LHS.GetCall();
count = 1;
for i in calls:
	if checkstatus.check(i) == 'Complete':
		call = i.encode('utf-8');
		call = call.decode('utf-8');
		print('{} {} {} '.format([count],i,checkstatus.check(i)));
		getPDF.loadPDF(i);
		onlinePdf.convertPDF();
		post2();
		count = count + 1;
		break;	
"""


post(call);

