#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import time;
import cloudconvert


def convertPDF():
	api = cloudconvert.Api('4vslZW0pFY89Wieg57lIPHSSHShab8FJ6b497Q8KXuShFRQVNCkqg1vqqG1pPwBz');
	process = api.convert({
		"inputformat": "pdf",
		"outputformat": "html",
		"input": "upload",
		"filename": "metadata.pdf",
		"timeout": 3,
		"file": open('metadata.pdf', 'rb')
	})
	print('[+]',process['message']);
	process.wait()
	process.download()
	print('[+]',process['message']);
	