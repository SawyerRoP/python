#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import time;
import codecs;
import regex;

f = codecs.open("metadata.html", 'r', 'utf-8')
document = BeautifulSoup(f.read(),'html.parser')
Problem = document.find_all('div');
count = len(Problem);

def getProblem():
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div');
	count = len(Problem);
	name = '';
	for i in range(count):
		if i >= 17:
			content = Problem[i].text;
			#print(content);
			re = regex.compile(r'สาเหตุการเสีย:(.*)',regex.I);
			name = re.findall(content);
		if name:
			file = re.findall(content);
			name = file[0]
			print('problem:',name);
			return name;
			#print(i);
	f.close();
def getSolvproblem():
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div');
	count = len(Problem);
	solvproblem = '';
	contentSolv = [];
	stop = 'ผลการบริการ';
	solvproblem2 = '';
	for i in range(count):	
		if i >= 17:
			solv_data = Problem[i].text;
			solv = regex.compile(r'วิธีการแก้ไข:(.*)',regex.I);
			solvproblem = solv.findall(solv_data);
		if solvproblem:
			solv2 = solv.findall(solv_data);
			solv3 = solv2[0];
			#print(solv3);
			#print(i);
			contentSolv.append(solv3);
			i = i + 1;
			solvproblem2 = Problem[i].text;
			if solvproblem2:
				stop2 = Problem[i].text;
				if regex.search(stop2,stop):
					#print('solvproblem:',solvproblem2);
					#print(i);
					contentSolv.append('');
					#print('solvproblem:',contentSolv[0])
					print('None line3');
					return contentSolv[0];
				else:
					contentSolv.append(stop2);
					con = contentSolv[0] + contentSolv[1];
					#print('solvproblem:',con);
					print('Have line3');
					return con;	
	f.close();
					
def regexName(n):
	re = regex.compile(r'นาย(.*)|คุณ(.*)',regex.I)
	if re.findall(n):
		file = re.findall(n);
		name = file[0]
		return name[0]
	else:
		return n;			
					
def getName():
	f = codecs.open("metadata.html", 'r', 'utf-8')
	document = BeautifulSoup(f.read(),'html.parser')
	Problem = document.find_all('div');
	count = len(Problem);
	check = 'ลงชื่อ';
	for i in range(count):
		if i >= 17:
			content_check = Problem[i].text;
			name = regex.compile(r'.*ตนุภพ(.*)|(.*)คำมุงคุณ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3640';
				return code;
				break;
			name = regex.compile(r'.*กนก(.*)|(.*)กาญจนวัฒนา',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0103';
				return code;
				break;
			name = regex.compile(r'.*สมอ(.*)|(.*)ปลาทอง',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'EDC';
				return code;
				break;
			name = regex.compile(r'.*กฤษณะ(.*)|(.*)อินน้อย',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3620';
				return code;
				break;
			name = regex.compile(r'.*กานต์(.*)|(.*)เสมมณี',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3646';
				return code;
				break;
			name = regex.compile(r'.*กุศล(.*)|(.*)สิงห์โต',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'R008';
				return code;
				break;
			name = regex.compile(r'.*เกล้าชัย(.*)|(.*)ชัยสิทธิ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '021';
				return code;
				break;
			name = regex.compile(r'.*เกิดตุลา(.*)|(.*)ศิลพร',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'R504';
				return code;
				break;
			name = regex.compile(r'.*จักรี(.*)|(.*)เรืองเนตร',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				print(name);
				code = '3672';
				return code;
				break;
			name = regex.compile(r'.*จิรพงศ์(.*)|(.*)หุตะการ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '015';
				return code;
				break;
			name = regex.compile(r'.*จีระศักดิ์(.*)|(.*)รักไทย',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				print(name);
				code = '020';
				return code;
				break;
			name = regex.compile(r'.*ฉัตรชัย(.*)|(.*)สำราญรักษ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3681';
				return code;
				break;
			name = regex.compile(r'.*ชาญวิทย์(.*)|(.*)นามด้วง',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3663';
				return code;
				break;
			name = regex.compile(r'.*ณัชญ์พิสิษฐ(.*)|(.*)พยาบาล',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'R508';
				return code;
				break;
			name = regex.compile(r'.*ณัฐวีร์(.*)|(.*)วุฒิสิทธิ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3654';
				return code;
				break;
			name = regex.compile(r'.*ณัฐวุฒิ(.*)|(.*)จิวสืบพงษ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3679';
				return code;
				break;
			name = regex.compile(r'.*เดชนรินทร์(.*)|(.*)อุปรี',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				print(name);
				code = '3671';
				return code;
				break;
			name = regex.compile(r'.*ต่อศักดิ์(.*)|(.*)แก้วคำมณี',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0170';
				return code;
				break;
			name = regex.compile(r'.*ทวีศักดิ์(.*)|(.*)สิทธินาค',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0165';
				return code;
				break;
			name = regex.compile(r'.*ทินกร(.*)|(.*)สอนสุภาพ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '080132';
				return code;
				break;
			name = regex.compile(r'.*ธัชชัย(.*)|(.*)รังไสว',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3677';
				return code;
				break;
			name = regex.compile(r'.*ธีรดิฐ(.*)|(.*)วีระประเสริฐ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3625';
				return code;
				break;
			name = regex.compile(r'.*นพณัฐ(.*)|(.*)เรืองสิทธิ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3647';
				return code;
				break;
			name = regex.compile(r'.*นิติภูมิ(.*)|(.*)ตองกลิ่น',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0176';
				return code;
				break;
			name = regex.compile(r'.*นิธิศ(.*)|(.*)ชูอภินันท์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'R509';
				return code;
				break;
			name = regex.compile(r'.*นิพนธ์(.*)|(.*)บุญเสริม',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0105';
				return code;
				break;
			name = regex.compile(r'.*บัณฑิตย์(.*)|(.*)ทิพย์โส',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0192';
				return code;
				break;
			name = regex.compile(r'.*ปิยะนันท์(.*)|(.*)เศวตมาลย์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'R502';
				return code;
				break;
			name = regex.compile(r'.*พิสิษฐ์(.*)|(.*)เล็กสวัสดิ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'RD0001';
				return code;
				break;
			name = regex.compile(r'.*ไพศาล(.*)|(.*)ขาวฉลาด',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3656';
				return code;
				break;
			name = regex.compile(r'.*ภวันดร(.*)|(.*)ค้าสุวรรณ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'R505';
				return code;
				break;
			name = regex.compile(r'.*ภัคภณ(.*)|(.*)พฤทธิ์นิมิต',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '012';
				return code;
				break;
			name = regex.compile(r'.*ภัทราวุธ(.*)|(.*)คงจันทร์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0096';
				return code;
				break;
			name = regex.compile(r'.*ภานุพงศ์(.*)|(.*)คณะศิริวงศ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3653';
				return code;
				break;
			name = regex.compile(r'.*มนตรี(.*)|(.*)ประวาฬ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3579';
				return code;
				break;
			name = regex.compile(r'.*ยุทธพล(.*)|(.*)สุริน',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '010';
				return code;
				break;
			name = regex.compile(r'.*วสันต์(.*)|(.*)ทองนนท์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0163';
				return code;
				break;
			name = regex.compile(r'.*วัชรพล(.*)|(.*)แต้มรู้',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3661';
				return code;
				break;
			name = regex.compile(r'.*วันชัย(.*)|(.*)สมหวัง',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3201';
				return code;
				break;
			name = regex.compile(r'.*วีระพงษ์(.*)|(.*)พุทธรักษา',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0156';
				return code;
				break;
			name = regex.compile(r'.*ศราวุฒิ(.*)|(.*)ชาวหวายสอ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3680';
				return code;
				break;
			name = regex.compile(r'.*สกนร์(.*)|(.*)เรืองชัยยศ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '014';
				return code;
				break;
			name = regex.compile(r'.*สมยศ(.*)|(.*)ชูกรณ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '011';
				return code;
				break;
			name = regex.compile(r'.*สมศักดิ์(.*)|(.*)บุญศรี',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '085';
				return code;
				break;
			name = regex.compile(r'.*สมัชญ์(.*)|(.*)ณ ระนอง',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3675';
				return code;
				break;
			name = regex.compile(r'.*สราวุฒิ(.*)|(.*)ฟองเขียว',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'R1014';
				return code;
				break;
			name = regex.compile(r'.*สุทธิพันธ์(.*)|(.*)โอบอ้อม',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '095';
				return code;
				break;
			name = regex.compile(r'.*สุริยะ(.*)|(.*)ยศสมบัติ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3673';
				return code;
				break;
			name = regex.compile(r'.*เสกสรร(.*)&&(.*)คงยอด',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3670';
				return code;
				break;
			name = regex.compile(r'.*เสกสรร(.*)|(.*)เล่งซุ่น',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3606';
				return code;
				break;
			name = regex.compile(r'.*อรรถสิทธิ์(.*)|(.*)สุคนธ์เที่ยง',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0065';
				return code;
				break;
			name = regex.compile(r'.*อรุณ(.*)|(.*)พึ่งเคหา',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '0016';
				return code;
				break;
			name = regex.compile(r'.*อัครพงศ์(.*)|(.*)พิมปุรุ',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3516';
				return code;
				break;
			name = regex.compile(r'.*อัศนัย(.*)|(.*)นาคกุล',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = 'RD2014';
				return code;
				break;
			name = regex.compile(r'.*ชนาธิป(.*)|(.*)ชื่นวงศ์',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(name);
				code = '3685';
				return code;
				break;
			
						
						
						
					
	f.close();			
#a = getName();
#print(a);		
#getName();		
#problem = getBodyClosecall();
#solv = getSolvproblem();

