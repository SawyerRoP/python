#!/usr/bin/env python
import requests;
from bs4 import BeautifulSoup
import re;
import login_LHS;
import checkstatus;
url = 'http://helpdesk.lhs.co.th/callnoclose.aspx'
session = login_LHS.login_getSession();
show = login_LHS.get_calls(url,session);
call = checkstatus.check(show);
for i in call:
	print(i);
