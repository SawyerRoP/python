#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os;
curDir = os.getcwd();
file_path = os.path.join(os.getcwd(),'pdf2htmlEX.exe');
command = file_path + ' metadata.pdf 123.html';
print(os.system(command));