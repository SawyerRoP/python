#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import get_time;
import re;
import time;

headers = {
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'Accept-Encoding': 'gzip, deflate',
	'Accept-Language': 'en-US,en;q=0.9',
	'Cache-Contro': 'max-age=0',
	'Connection': 'keep-alive',
	'Content-Length': '364',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Host': 'helpdesk.lhs.co.th',
	'Origin': 'http://helpdesk.lhs.co.th',
	'Referer': 'http://helpdesk.lhs.co.th/',
	'Cookie': '?AspxAutoDetectCookieSupport=1;',
	'Upgrade-Insecure-Requests': '1',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
	}


url = 'http://helpdesk.lhs.co.th/';
url_login = 'http://helpdesk.lhs.co.th/login.aspx';
urlclose_call = 'http://helpdesk.lhs.co.th/closecall.aspx'
page = requests.get(url);
soup = BeautifulSoup(page.content, 'html.parser')
__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);

data = {	      
	"__LASTFOCUS":"",
	"__VIEWSTATE":__VIEWSTATE,
	"__EVENTTARGET":"",
	"__EVENTARGUMENT":"",
	"__VIEWSTATEGENERATOR":__VIEWSTATEGENERATOR,
	"__EVENTVALIDATION":__EVENTVALIDATION,
	"tuser":"tech",
	"tpwd":"user",
	"btsignin":"Sign In"
	}

load = requests.session();
page = load.post(url_login,data = data,headers = headers);
close = load.get(urlclose_call);
cookie = load.cookies.get_dict();
print(cookie['ASP.NET_SessionId']);