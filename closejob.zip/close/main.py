#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import get_time;
import re;
import time;
import pdf2html;
import listTech;
import onlinePdf;
import checkstatus;
import login_LHS;
import getPDF;

headers = {
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'Accept-Encoding': 'gzip, deflate',
	'Accept-Language': 'en-US,en;q=0.9',
	'Cache-Contro': 'max-age=0',
	'Connection': 'keep-alive',
	'Content-Length': '364',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Host': 'helpdesk.lhs.co.th',
	'Origin': 'http://helpdesk.lhs.co.th',
	'Referer': 'http://helpdesk.lhs.co.th/',
	'Cookie': '?AspxAutoDetectCookieSupport=1;',
	'Upgrade-Insecure-Requests': '1',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
}


url = 'http://helpdesk.lhs.co.th/';
url_login = 'http://helpdesk.lhs.co.th/login.aspx';
urlclose_call = 'http://helpdesk.lhs.co.th/closecall.aspx'
page = requests.get(url);
soup = BeautifulSoup(page.content, 'html.parser')
__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);

data = {
	"__LASTFOCUS":"",
	"__VIEWSTATE":__VIEWSTATE,
	"__EVENTTARGET":"",
	"__EVENTARGUMENT":"",
	"__VIEWSTATEGENERATOR":__VIEWSTATEGENERATOR,
	"__EVENTVALIDATION":__EVENTVALIDATION,
	"tuser":"tech",
	"tpwd":"user",
	"btsignin":"Sign In"
}

load = requests.session();
page = load.post(url_login,data = data,headers = headers);
close = load.get(urlclose_call);
cookie = cookie = load.cookies.get_dict();
soup = BeautifulSoup(close.content, 'html.parser')
__VIEWSTATE = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATE" ,'name':"__VIEWSTATE"})['value']);
__VIEWSTATEGENERATOR = str(soup.find('input', {'type':'hidden','id':"__VIEWSTATEGENERATOR" ,'name':"__VIEWSTATEGENERATOR"})['value']);
__EVENTVALIDATION = str(soup.find('input', {'type':'hidden','id':"__EVENTVALIDATION" ,'name':"__EVENTVALIDATION"})['value']);

headersPost = {
	'Host': 'helpdesk.lhs.co.th',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-US,en;q=0.5',
	'Accept-Encoding': 'gzip, deflate',
	'Referer': 'http://helpdesk.lhs.co.th/closecall.aspx',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Content-Length': '10083',
	'Connection': 'keep-alive',
	'Cookie': 'AspxAutoDetectCookieSupport=1; ASP.NET_SessionId=' + cookie['ASP.NET_SessionId'],
	'Upgrade-Insecure-Requests': '1'
}
#print(close.text);
def postCloseCall(call,codename):
	if __VIEWSTATE:
		print('[+]viewstate OK')
		time.sleep(1);
	if __VIEWSTATEGENERATOR:
		print('[+]viewstegenerator OK')
		time.sleep(1);
	if __EVENTVALIDATION:
		print('[+]eventvalidation OK');
		time.sleep(1);
		print('[+]Cookies:',cookie['ASP.NET_SessionId']);
	name,problem,solv = pdf2html.getBodyClosecall();
	name = name.decode('utf-8');
	pro = problem.decode('utf-8');
	solveproblem = " ".join(str(x) for x in solv);
	detail = pro + solveproblem;
	day,hour,minute,mount,year = get_time.getTime();
	d = day.decode('utf-8');
	h = hour.decode('utf-8');
	mi = minute.decode('utf-8');
	m = mount.decode('utf-8');
	y = year.decode('utf-8');
	print('[+]codeName:',getCodeName);
	print('[+]Date: {}:{} {}.{}.{} '.format(h,mi,d,m,y));
	#print(getCodeName);
	print(solveproblem);

	dataPost = {
		'__EVENTTARGET':'',
		'__EVENTARGUMENT':'',
		'__LASTFOCUS':'',
		'__VIEWSTATE':__VIEWSTATE,
		'__VIEWSTATEGENERATOR':__VIEWSTATEGENERATOR,
		'__VIEWSTATEENCRYPTED':'',
		'__EVENTVALIDATION':__EVENTVALIDATION,
		'tcall':call,
		'tdetail':detail,
		'ddate':d,
		'dmonth':m,
		'dyear': y,
		'dhour':h,
		'tminute':mi,
		'dtech':codename,
		'TextBox1':'0',
		'rbt1': '1',
		'Button1': 'บันทึกข้อมูล'
	}

	post = load.post(urlclose_call,dataPost,headers = headersPost);
	if post.status_code == 200:
		print('complet');
	#print(result);
	"""
		with open('name.txt', 'wb') as f:
			 f.write(data.encode('utf-8'))
	"""
calls = [];
calls = login_LHS.GetCall();
count = 1;
for i in calls:
	if checkstatus.check(i) == 'Complete':
		call = i.encode('utf-8');
		call = call.decode('utf-8');
		print('{} {} {} '.format([count],i,checkstatus.check(i)));
		getPDF.loadPDF(i);
		onlinePdf.convertPDF();
		getCodeName = listTech.getRegexName();
		getCodeName = getCodeName.decode('utf-8');
		postCloseCall(call,getCodeName);
		count = count + 1;
	
