#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests;
from bs4 import BeautifulSoup;
import time;
import codecs;
import regex;

f = codecs.open("metadata.html", 'r', 'utf-8')
document = BeautifulSoup(f.read(),'html.parser')
Problem = document.find_all('div');
count = len(Problem);

def getProblem():
	name = '';
	for i in range(count):
		if i >= 17:
			content = Problem[i].text;
			#print(content);
			re = regex.compile(r'สาเหตุการเสีย:(.*)',regex.I);
			name = re.findall(content);
		if name:
			file = re.findall(content);
			name = file[0]
			print('problem:',name);
			return name;
			#print(i);
def getSolvproblem():
	solvproblem = '';
	contentSolv = [];
	stop = 'ผลการบริการ';
	solvproblem2 = '';
	for i in range(count):	
		if i >= 17:
			solv_data = Problem[i].text;
			solv = regex.compile(r'วิธีการแก้ไข:(.*)',regex.I);
			solvproblem = solv.findall(solv_data);
		if solvproblem:
			solv2 = solv.findall(solv_data);
			solv3 = solv2[0];
			#print(solv3);
			#print(i);
			contentSolv.append(solv3);
			i = i + 1;
			solvproblem2 = Problem[i].text;
			if solvproblem2:
				stop2 = Problem[i].text;
				if regex.search(stop2,stop):
					#print('solvproblem:',solvproblem2);
					#print(i);
					contentSolv.append('');
					print('solvproblem:',contentSolv[0])
					print('None line3');
					return contentSolv[0];
				else:
					contentSolv.append(stop2);
					con = contentSolv[0] + contentSolv[1];
					print('solvproblem:',con);
					print('Have line3');
					return con;	
					
def getName():
	check = 'ลงชื่อ';
	for i in range(count):
		if i >= 17:
			content_check = Problem[i].text;
			name = regex.compile(r'ลงชื่อ(\.(.*))',regex.I);
			if name.findall(content_check):
				content_name = name.findall(content_check);
				name = content_name[0];
				#print(content_check);
				i = i + 1;
				Name = Problem[i].text;
				print('[+]GetName OK');
				return Name;
				break;
		
#getName();		
#problem = getBodyClosecall();
#solv = getSolvproblem();

